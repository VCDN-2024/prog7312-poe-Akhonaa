﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WeGotYou.Models;


namespace WeGotYou
{
    public partial class ReportIssuesWindow : Window
    {
        private List<string> mediaAttachments = new List<string>();
        private List<IssueReport> reportedIssues = new List<IssueReport>();

        // Priority heap for service requests
       private static PriorityQueue<ServiceRequest, int> serviceRequestHeap = new PriorityQueue<ServiceRequest, int>();

        private static int requestCounter = 0; // Static counter for generating unique IDs
        public delegate void IssueReportedHandler();
        public event IssueReportedHandler IssueReported;
        public static List<ServiceRequest> ServiceRequests
        {
            get
            {
                // Extract all service requests from the priority queue
                var requests = new List<ServiceRequest>();
                while (serviceRequestHeap.Count > 0)
                {
                    if (serviceRequestHeap.TryDequeue(out var request, out _))
                    {
                        requests.Add(request);
                    }
                }

                // Re-enqueue the extracted requests to maintain the priority queue state
                foreach (var request in requests)
                {
                    serviceRequestHeap.Enqueue(request, GetPriorityValue(request.Priority));
                }

                return requests;
            }
        }




        public ReportIssuesWindow()
        {
            InitializeComponent();
            UpdateProgress();
            UpdatePlaceholders(); // Initialize placeholders
        }

        private void AttachFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select Files to Attach",
                Filter = "Image Files|*.jpg;*.jpeg;*.png|PDF Files|*.pdf|All Files|*.*",
                Multiselect = true
            };

            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string filename in openFileDialog.FileNames)
                {
                    mediaAttachments.Add(filename);
                }
                AttachedFilesTextBlock.Text = $"{mediaAttachments.Count} file(s) attached";
                UpdateProgress();
                EngagementLabel.Text = "Great! You've attached your files.";
            }
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string location = LocationTextBox.Text.Trim();
            string category = (CategoryComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string priority = (PriorityComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string description = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();

            if (string.IsNullOrEmpty(location) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please fill in all fields.", "Incomplete Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int priorityValue = GetPriorityValue(priority);
            ServiceRequest newRequest = new ServiceRequest
            {
                RequestId = $"SR{++requestCounter:000}",
                Description = description,
                Location = location,
                Category = category,
                Status = "Pending",
                ReportedAt = DateTime.Now,
                Priority = priority
            };

            serviceRequestHeap.Enqueue(newRequest, priorityValue);

            // Add initial status to the history tree
            statusHistoryTree.AddStatus(newRequest.RequestId, "Pending", DateTime.Now, "System");

            LocationTextBox.Clear();
            CategoryComboBox.SelectedIndex = -1;
            DescriptionRichTextBox.Document.Blocks.Clear();
            mediaAttachments.Clear();
            AttachedFilesTextBlock.Text = "No files attached";
            UpdateProgress();
            EngagementLabel.Text = "Thank you! Your issue has been reported.";

            MessageBox.Show("Issue reported successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            IssueReported?.Invoke();
        }

        private static int GetPriorityValue(string priority)
        {
            return priority switch
            {
                "High" => 1,
                "Medium" => 2,
                "Low" => 3,
                _ => int.MaxValue,
            };
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void UpdateProgress()
        {
            int completedFields = 0;
            if (!string.IsNullOrEmpty(LocationTextBox.Text)) completedFields++;
            if (CategoryComboBox.SelectedIndex != -1) completedFields++;
            if (!string.IsNullOrEmpty(new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim())) completedFields++;
            if (mediaAttachments.Count > 0) completedFields++;

            double progress = (completedFields / 4.0) * 100;
            ProgressBar.Value = progress;

            EngagementLabel.Text = progress switch
            {
                100 => "You're all set to submit your issue!",
                >= 75 => "Almost there! Just a bit more to go.",
                >= 50 => "Good progress! Keep going.",
                >= 25 => "Getting started is great!",
                _ => "Fill out the form to report an issue!"
            };
        }

        private void ViewIssuesButton_Click(object sender, RoutedEventArgs e)
        {
            if (serviceRequestHeap.Count == 0)
            {
                MessageBox.Show("No issues reported yet.", "No Data", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            StringBuilder issuesList = new StringBuilder();
            var tempQueue = new PriorityQueue<ServiceRequest, int>();

            // Display all requests in priority order
            while (serviceRequestHeap.TryDequeue(out var request, out var priority))
            {
                issuesList.AppendLine($"ID: {request.RequestId}\nCategory: {request.Category}\nLocation: {request.Location}\nPriority: {request.Priority}\nDescription: {request.Description}\nStatus: {request.Status}\nReported At: {request.ReportedAt}\n");
                issuesList.AppendLine("-----------");

                // Re-add the item back to the queue
                tempQueue.Enqueue(request, priority);
            }

            // Restore the original queue
            serviceRequestHeap = tempQueue;

            MessageBox.Show(issuesList.ToString(), "Reported Issues (Priority Order)", MessageBoxButton.OK, MessageBoxImage.Information);
        }



        private void LocationTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LocationPlaceholder.Visibility = string.IsNullOrWhiteSpace(LocationTextBox.Text) ? Visibility.Visible : Visibility.Hidden;
            UpdateProgress();
        }

        private void DescriptionRichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string descriptionText = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();
            DescriptionPlaceholder.Visibility = string.IsNullOrWhiteSpace(descriptionText) ? Visibility.Visible : Visibility.Hidden;
            UpdateProgress();
        }

        private void UpdatePlaceholders()
        {
            LocationPlaceholder.Visibility = string.IsNullOrWhiteSpace(LocationTextBox.Text) ? Visibility.Visible : Visibility.Hidden;
            string descriptionText = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();
            DescriptionPlaceholder.Visibility = string.IsNullOrWhiteSpace(descriptionText) ? Visibility.Visible : Visibility.Hidden;
        }

        private void CategoryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateProgress();
        }

        private void PriorityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateProgress();
        }

        private StatusHistoryTree statusHistoryTree = new StatusHistoryTree();

       private void UpdateStatus(string requestId, string newStatus, string updatedBy)
        {
            DateTime updatedAt = DateTime.Now;

            // Add the new status to the history tree
            statusHistoryTree.AddStatus(requestId, newStatus, updatedAt, updatedBy);

            // Example of reflecting this in the UI or data store
            MessageBox.Show($"Status updated to '{newStatus}' for Request ID: {requestId}");
        }
        



    }
}