﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WeGotYou.Models;


namespace WeGotYou
{
    /// <summary>
    /// Interaction logic for ReportIssuesWindow.xaml
    /// </summary>
    public partial class ReportIssuesWindow : Window
    {
        private List<string> mediaAttachments = new List<string>();
        private List<IssueReport> reportedIssues = new List<IssueReport>();
        // A static list to store all service requests submitted by users
        public static List<ServiceRequest> ServiceRequests = new List<ServiceRequest>();
        private static int requestCounter = 0; // Static counter for generating unique IDs
        public delegate void IssueReportedHandler();
        public event IssueReportedHandler IssueReported;

        public ReportIssuesWindow()
        {
            InitializeComponent();
            UpdateProgress();
            UpdatePlaceholders(); // Initialize placeholders
        }

        // Event handler for the Attach File button
        private void AttachFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select Files to Attach";
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png|PDF Files|*.pdf|All Files|*.*";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string filename in openFileDialog.FileNames)
                {
                    mediaAttachments.Add(filename);
                }
                AttachedFilesTextBlock.Text = $"{mediaAttachments.Count} file(s) attached";
                UpdateProgress();
                EngagementLabel.Text = "Great! You've attached your files.";
            }
        }

        // Event handler for the Submit button
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string location = LocationTextBox.Text.Trim();
            string category = (CategoryComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string priority = (PriorityComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string description = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();
            

            // Validation
            if (string.IsNullOrEmpty(location) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please fill in all fields.", "Incomplete Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Create a new issue report
            IssueReport report = new IssueReport
            {
                Location = location,
                Category = category,
                Description = description,
                MediaAttachments = new List<string>(mediaAttachments),
                ReportedAt = DateTime.Now,
                RequestId = $"SR{++requestCounter:000}", // Generate unique ID
                Priority = priority
            };

            // Store the report (for now, add to the list)
            reportedIssues.Add(report);

           ServiceRequest newRequest = new ServiceRequest
            {
                RequestId = report.RequestId,
                Description = report.Description,
                Location = report.Location,
                Category = report.Category,
                Status = "Pending", // Set initial status
                ReportedAt = report.ReportedAt,
                Priority = report.Priority
            };

            ServiceRequests.Add(newRequest);

            // Clear the form
            LocationTextBox.Clear();
            CategoryComboBox.SelectedIndex = -1;
            DescriptionRichTextBox.Document.Blocks.Clear();
            mediaAttachments.Clear();
            AttachedFilesTextBlock.Text = "No files attached";
            UpdateProgress();
            EngagementLabel.Text = "Thank you! Your issue has been reported.";

            MessageBox.Show("Issue reported successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            IssueReported?.Invoke();

        }

        // Event handler for the Back button
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        // Update the progress bar based on form completion
        private void UpdateProgress()
        {
            int completedFields = 0;
            if (!string.IsNullOrEmpty(LocationTextBox.Text)) completedFields++;
            if (CategoryComboBox.SelectedIndex != -1) completedFields++;
            if (!string.IsNullOrEmpty(new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim())) completedFields++;
            if (mediaAttachments.Count > 0) completedFields++;

            // Calculate progress (out of 100)
            double progress = (completedFields / 4.0) * 100;
            ProgressBar.Value = progress;

            // Update engagement label based on progress
            if (progress == 100)
            {
                EngagementLabel.Text = "You're all set to submit your issue!";
            }
            else if (progress >= 75)
            {
                EngagementLabel.Text = "Almost there! Just a bit more to go.";
            }
            else if (progress >= 50)
            {
                EngagementLabel.Text = "Good progress! Keep going.";
            }
            else if (progress >= 25)
            {
                EngagementLabel.Text = "Getting started is great!";
            }
            else
            {
                EngagementLabel.Text = "Fill out the form to report an issue!";
            }
        }

        // Placeholder handling for Location TextBox
        private void LocationTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LocationTextBox.Text))
            {
                LocationPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                LocationPlaceholder.Visibility = Visibility.Hidden;
            }
            UpdateProgress();
        }

        // Placeholder handling for RichTextBox
        private void DescriptionRichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string descriptionText = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();

            if (string.IsNullOrWhiteSpace(descriptionText))
            {
                DescriptionPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                DescriptionPlaceholder.Visibility = Visibility.Hidden;
            }
            UpdateProgress();
        }

        // Update placeholders initially
        private void UpdatePlaceholders()
        {
            LocationPlaceholder.Visibility = string.IsNullOrWhiteSpace(LocationTextBox.Text) ? Visibility.Visible : Visibility.Hidden;
            string descriptionText = new TextRange(DescriptionRichTextBox.Document.ContentStart, DescriptionRichTextBox.Document.ContentEnd).Text.Trim();
            DescriptionPlaceholder.Visibility = string.IsNullOrWhiteSpace(descriptionText) ? Visibility.Visible : Visibility.Hidden;
        }

        //Update progress as user interacts with the form
        private void CategoryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateProgress();
        }

        private void PriorityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateProgress();
        }
    }
}
