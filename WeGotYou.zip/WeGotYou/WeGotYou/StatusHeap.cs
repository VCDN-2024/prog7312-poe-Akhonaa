﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeGotYou
{
    public class StatusHeap
    {
        private List<StatusHistory> heap;

        public StatusHeap()
        {
            heap = new List<StatusHistory>();
        }

        private int GetParentIndex(int index) => (index - 1) / 2;
        private int GetLeftChildIndex(int index) => 2 * index + 1;
        private int GetRightChildIndex(int index) => 2 * index + 2;

        public void Insert(StatusHistory item)
        {
            heap.Add(item);
            HeapifyUp(heap.Count - 1);
        }

        private void HeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = GetParentIndex(index);
                if (Compare(heap[index], heap[parentIndex]) > 0)
                {
                    Swap(index, parentIndex);
                    index = parentIndex;
                }
                else
                {
                    break;
                }
            }
        }

        private void HeapifyDown(int index)
        {
            int maxIndex = index;
            int size = heap.Count;

            while (true)
            {
                int leftChild = GetLeftChildIndex(index);
                int rightChild = GetRightChildIndex(index);

                if (leftChild < size && Compare(heap[leftChild], heap[maxIndex]) > 0)
                    maxIndex = leftChild;

                if (rightChild < size && Compare(heap[rightChild], heap[maxIndex]) > 0)
                    maxIndex = rightChild;

                if (maxIndex == index)
                    break;

                Swap(index, maxIndex);
                index = maxIndex;
            }
        }

        private int Compare(StatusHistory a, StatusHistory b)
        {
            // Priority order: Critical > In Progress > Pending > Scheduled > Completed
            string[] priorityOrder = { "Critical", "In Progress", "Pending", "Scheduled", "Completed" };

            int statusA = Array.IndexOf(priorityOrder, a.Status);
            int statusB = Array.IndexOf(priorityOrder, b.Status);

            if (statusA != statusB)
                return statusB - statusA; // Reverse order so higher priority is at top

            return b.Date.CompareTo(a.Date); // More recent dates have higher priority
        }

        private void Swap(int i, int j)
        {
            var temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public List<StatusHistory> GetAllSorted()
        {
            var result = new List<StatusHistory>();
            var tempHeap = new List<StatusHistory>(heap);

            while (heap.Count > 0)
            {
                result.Add(ExtractMax());
            }

            heap = tempHeap; // Restore the heap
            return result;
        }

        public StatusHistory ExtractMax()
        {
            if (heap.Count == 0)
                throw new InvalidOperationException("Heap is empty");

            var max = heap[0];
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);

            if (heap.Count > 0)
                HeapifyDown(0);

            return max;
        }

        public List<StatusHistory> FilterByRequestId(string requestId)
        {
            return heap.FindAll(x => x.RequestID.Equals(requestId, StringComparison.OrdinalIgnoreCase));
        }

        public List<StatusHistory> FilterByStatus(string status)
        {
            return heap.FindAll(x => x.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
        }

        public List<StatusHistory> FilterByDate(DateTime date)
        {
            return heap.FindAll(x => x.Date.Date == date.Date);
        }

        public List<StatusHistory> FilterByUpdatedBy(string updatedBy)
        {
            return heap.FindAll(x => x.UpdatedBy.Equals(updatedBy, StringComparison.OrdinalIgnoreCase));
        }

        // Class to hold status history
        public class StatusHistory
        {
            public string RequestID { get; set; }
            public string Status { get; set; }
            public string UpdatedBy { get; set; }
            public DateTime Date { get; set; }
        }
    }
}
