﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeGotYou;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Wpf;

using OxyPlot.Series;

namespace WeGotYou
{
    public class StatusNode
    {
        public string Status { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string UpdatedBy { get; set; }
        public StatusNode Next { get; set; }

        public StatusNode(string status, DateTime updatedAt, string updatedBy)
        {
            Status = status;
            UpdatedAt = updatedAt;
            UpdatedBy = updatedBy;
            Next = null;
        }
    }

    public class StatusHistoryTree
    {
        private readonly Dictionary<string, List<StatusHistoryEntry>> historyTree = new();

        // Adds a status entry to the history for a specific request ID.
        public void AddStatus(string requestId, string status, DateTime updatedAt, string updatedBy)
        {
            if (!historyTree.ContainsKey(requestId))
            {
                historyTree[requestId] = new List<StatusHistoryEntry>();
            }

            historyTree[requestId].Add(new StatusHistoryEntry
            {
                Status = status,
                UpdatedAt = updatedAt,
                UpdatedBy = updatedBy
            });

            // Debugging log
            Console.WriteLine($"Added status: [RequestID: {requestId}, Status: {status}, UpdatedAt: {updatedAt}, UpdatedBy: {updatedBy}]");
        }

        // Retrieves the history for a specific request ID.
        public List<StatusHistoryEntry> GetStatusHistory(string requestId)
        {
            if (historyTree.TryGetValue(requestId, out var history))
            {
                return history;
            }

            return null;
        }

        public IEnumerable<StatusHistoryEntry> GetAllHistories()
        {
            return historyTree.Values.SelectMany(history => history);
        }

    }

    public class StatusHistoryEntry
    {
        public string Status { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string UpdatedBy { get; set; }
    }


}