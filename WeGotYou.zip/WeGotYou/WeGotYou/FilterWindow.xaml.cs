﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WeGotYou
{
    public partial class FilterWindow : Window
    {
        private LocalEventsWindow mainWindow;

        public FilterWindow(LocalEventsWindow mainWin)
        {
            InitializeComponent();
            mainWindow = mainWin;
        }

        private void Sort_Click(object sender, RoutedEventArgs e)
        {
            // Sort by Date
            if (LatestCheckbox.IsChecked == true)
            {
                mainWindow.SortEventsByDate(latest: true); // Sort by latest date
            }
            else if (EarliestCheckbox.IsChecked == true)
            {
                mainWindow.SortEventsByDate(latest: false); // Sort by earliest date
            }

            // Sort by Category remains unchanged...
            var selectedCategories = new System.Collections.Generic.List<string>();
            if (AllCheckbox.IsChecked == true)
            {
                selectedCategories.AddRange(mainWindow.GetAllCategories());
            }
            else
            {
                if (EnvironmentCheckbox.IsChecked == true) selectedCategories.Add("Environment");
                if (CommerceCheckbox.IsChecked == true) selectedCategories.Add("Commerce");
                if (SportsCheckbox.IsChecked == true) selectedCategories.Add("Sports");
                if (EntertainmentCheckbox.IsChecked == true) selectedCategories.Add("Entertainment");
                if (EmploymentCheckbox.IsChecked == true) selectedCategories.Add("Employment");
            }

            mainWindow.FilterEventsByCategory(selectedCategories);
            this.Close();
        }
    }
}