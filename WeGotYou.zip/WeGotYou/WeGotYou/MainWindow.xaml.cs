﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WeGotYou
{
    public partial class MainWindow : Window
    {
        private LocalEventsWindow localEventsWindow;
        private List<Event> accumulatedRecommendations = new List<Event>(); // List to accumulate recommendations

        public MainWindow()
        {
            InitializeComponent();
            LoadRecentServiceRequests();

        }

        private void LoadRecentServiceRequests()
        {
            // Load the recent service requests into the DataGrid
            RecentRequestsDataGrid.ItemsSource = ReportIssuesWindow.ServiceRequests.Take(5).ToList();
        }

        private void ReportIssuesButton_Click(object sender, RoutedEventArgs e)
        {
            ReportIssuesWindow reportWindow = new ReportIssuesWindow();
            reportWindow.IssueReported += OnIssueReported;
            reportWindow.Show();
            this.Close();
        }

        private void FeedbackButton_Click(object sender, RoutedEventArgs e)
        {
            FeedbackWindow feedbackWindow = new FeedbackWindow();
            feedbackWindow.Show();
        }

        private void LocalEventsButton_Click(object sender, RoutedEventArgs e)
        {
            if (localEventsWindow == null)
            {
                localEventsWindow = new LocalEventsWindow();
            }
            localEventsWindow.Show();
            this.Hide();
        }

        private void ShowRecommendationsButton_Click(object sender, RoutedEventArgs e)
        {
            if (localEventsWindow == null)
            {
                localEventsWindow = new LocalEventsWindow();
            }

            // Fetch the search history from LocalEventsWindow
            var searchHistory = localEventsWindow.GetSearchHistory();

            if (searchHistory.Count > 0)
            {
                // Determine the top keywords from the search history
                var recommendedKeywords = searchHistory.OrderByDescending(kvp => kvp.Value)
                                                      .Take(3)
                                                      .Select(kvp => kvp.Key)
                                                      .ToList();

                // Find events that match the recommended keywords
                var newRecommendations = localEventsWindow.eventsList
                    .Where(ev => recommendedKeywords.Any(keyword => ev.Title.ToLower().Contains(keyword)))
                    .ToList();

                // Add new recommendations while avoiding duplicates
                foreach (var ev in newRecommendations)
                {
                    if (!accumulatedRecommendations.Contains(ev))
                    {
                        accumulatedRecommendations.Add(ev); // Add to accumulated recommendations
                    }
                }

                if (accumulatedRecommendations.Any())
                {
                    // Display the accumulated recommendations
                    MessageBox.Show("Recommended Events based on your searches:");
                    foreach (var ev in accumulatedRecommendations)
                    {
                        MessageBox.Show($"{ev.Title} - {ev.Date.ToShortDateString()} ({ev.Category})");
                    }
                }
                else
                {
                    MessageBox.Show("No new recommendations available based on your search history.");
                }
            }
            else
            {
                MessageBox.Show("No search history available for recommendations.");
            }
        }
         private void ViewAllRequestsButton_Click(object sender, RoutedEventArgs e)
        {
            var statusForm = new ServiceRequestStatusForm(ReportIssuesWindow.ServiceRequests);
            statusForm.Show();
        }

        private void OnIssueReported()
        {
            LoadRecentServiceRequests();
        }

    }
}