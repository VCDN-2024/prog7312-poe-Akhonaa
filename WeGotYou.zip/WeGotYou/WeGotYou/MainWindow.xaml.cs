﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WeGotYou
{
    public partial class MainWindow : Window
    {
        private LocalEventsWindow localEventsWindow;
        private List<Event> accumulatedRecommendations = new List<Event>();
        private StatusHistoryTree statusHistoryTree;


        public MainWindow()
        {
            InitializeComponent();
            statusHistoryTree = new StatusHistoryTree();
            LoadRecentServiceRequests();
        }

        private void LoadRecentServiceRequests()
        {
            // Load the recent service requests into the DataGrid
            RecentRequestsDataGrid.ItemsSource = ReportIssuesWindow.ServiceRequests.Take(5).ToList();
        }

        private void ReportIssuesButton_Click(object sender, RoutedEventArgs e)
        {
            var reportWindow = new ReportIssuesWindow();
            reportWindow.IssueReported += OnIssueReported;

            // Add a sample status update for demonstration purposes
            reportWindow.IssueReported += () =>
            {
                var requestId = Guid.NewGuid().ToString();
                statusHistoryTree.AddStatus(requestId, "Reported", DateTime.Now, "User1");


            };

            reportWindow.Show();
            this.Close();
        }

        private void LocalEventsButton_Click(object sender, RoutedEventArgs e)
        {
            if (localEventsWindow == null)
            {
                localEventsWindow = new LocalEventsWindow();
            }
            localEventsWindow.Show();
            this.Hide();
        }

        private void ShowRecommendationsButton_Click(object sender, RoutedEventArgs e)
        {
            if (localEventsWindow == null)
            {
                localEventsWindow = new LocalEventsWindow();
            }

            var searchHistory = localEventsWindow.GetSearchHistory();

            if (searchHistory.Count > 0)
            {
                var recommendedKeywords = searchHistory
                    .OrderByDescending(kvp => kvp.Value)
                    .Take(3)
                    .Select(kvp => kvp.Key)
                    .ToList();

                var newRecommendations = localEventsWindow.eventsList
                    .Where(ev => recommendedKeywords.Any(keyword => ev.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase)))
                    .ToList();

                foreach (var ev in newRecommendations)
                {
                    if (!accumulatedRecommendations.Contains(ev))
                    {
                        accumulatedRecommendations.Add(ev);
                    }
                }

                if (accumulatedRecommendations.Any())
                {
                    var message = "Recommended Events based on your searches:\n" +
                                  string.Join("\n", accumulatedRecommendations.Select(ev =>
                                      $"{ev.Title} - {ev.Date.ToShortDateString()} ({ev.Category})"));
                    MessageBox.Show(message, "Recommendations");
                }
                else
                {
                    MessageBox.Show("No new recommendations available based on your search history.");
                }
            }
            else
            {
                MessageBox.Show("No search history available for recommendations.");
            }
        }

        private void ViewAllRequestsButton_Click(object sender, RoutedEventArgs e)
        {
            var statusForm = new ServiceRequestStatusForm(ReportIssuesWindow.ServiceRequests);
            statusForm.Show();
        }

        private void StatusHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            // Pass the status history tree to the new window
           /*-- var statusHistoryWindow = new StatusHistoryWindow(statusHistoryTree);
            statusHistoryWindow.ShowDialog();--*/

            StatusHistoryWindow statusHistoryWindow = new StatusHistoryWindow(statusHistoryTree);
            statusHistoryWindow.Show();
        }


        private void OnIssueReported()
        {
            LoadRecentServiceRequests();
        }
    }
}