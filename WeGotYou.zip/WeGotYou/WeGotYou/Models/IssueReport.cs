﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeGotYou.Models
{
    class IssueReport
    {
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public List<string> MediaAttachments { get; set; }
        public DateTime ReportedAt { get; set; }
        public string RequestId { get; set; }

        public string Priority { get; set; }
    }
}
