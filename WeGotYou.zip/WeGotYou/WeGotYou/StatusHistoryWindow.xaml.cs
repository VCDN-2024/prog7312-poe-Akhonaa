﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Wpf;

using OxyPlot.Series;
using WeGotYou;
using static WeGotYou.StatusHeap;

namespace WeGotYou
{
    public partial class StatusHistoryWindow : Window
    {
        private StatusHeap statusHeap;
        private StatusHistoryTree statusHistoryTree;

        public StatusHistoryWindow(StatusHistoryTree tree)
        {
            InitializeComponent();
            statusHistoryTree = tree;
            statusHeap = new StatusHeap();
            LoadSampleData();
            UpdatePriorityVisualization(statusHeap.GetAllSorted());
        }

        private void LoadSampleData()
        {
            // Load sample data into the heap
            var sampleData = new List<StatusHistory>
            {
                new StatusHistory { RequestID = "SR001", Status = "Critical", UpdatedBy = "Admin", Date = DateTime.Now.AddDays(-7) },
                new StatusHistory { RequestID = "SR002", Status = "In Progress", UpdatedBy = "Worker1", Date = DateTime.Now.AddDays(-5) },
                new StatusHistory { RequestID = "SR003", Status = "Completed", UpdatedBy = "Admin", Date = DateTime.Now.AddDays(-3) },
                new StatusHistory { RequestID = "SR004", Status = "Pending", UpdatedBy = "Admin", Date = DateTime.Now.AddDays(-10) },
                new StatusHistory { RequestID = "SR005", Status = "In Progress", UpdatedBy = "Worker2", Date = DateTime.Now.AddDays(-8) },
                new StatusHistory { RequestID = "SR006", Status = "Scheduled", UpdatedBy = "Admin", Date = DateTime.Now.AddDays(-4) }
            };

            foreach (var item in sampleData)
            {
                statusHeap.Insert(item);
            }
        }

        private void UpdatePriorityVisualization(List<StatusHistory> data)
        {
            PriorityTreeView.Items.Clear();

            // Group items by status
            var statusGroups = data.GroupBy(x => x.Status).OrderBy(g => GetStatusPriority(g.Key));

            foreach (var group in statusGroups)
            {
                var statusItem = new TreeViewItem
                {
                    Header = $"{group.Key} ({group.Count()})",
                    Foreground = GetStatusBrush(group.Key)
                };

                foreach (var request in group.OrderByDescending(r => r.Date))
                {
                    statusItem.Items.Add(new TreeViewItem
                    {
                        Header = $"ID: {request.RequestID} - {request.Date.ToShortDateString()} - {request.UpdatedBy}",
                        Foreground = Brushes.White
                    });
                }

                PriorityTreeView.Items.Add(statusItem);
            }
        }

        private int GetStatusPriority(string status)
        {
            return status switch
            {
                "Critical" => 0,
                "In Progress" => 1,
                "Pending" => 2,
                "Scheduled" => 3,
                "Completed" => 4,
                _ => 5
            };
        }

        private Brush GetStatusBrush(string status)
        {
            return status switch
            {
                "Critical" => Brushes.Red,
                "In Progress" => Brushes.Yellow,
                "Pending" => Brushes.Orange,
                "Scheduled" => Brushes.LightBlue,
                "Completed" => Brushes.LightGreen,
                _ => Brushes.White
            };
        }

        private void ViewHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            string requestId = RequestIdTextBox.Text.Trim();

            if (string.IsNullOrEmpty(requestId))
            {
                MessageBox.Show("Please enter a valid Request ID.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var filteredData = statusHeap.FilterByRequestId(requestId);

            if (!filteredData.Any())
            {
                MessageBox.Show("No history found for the provided Request ID.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            HistoryDataGrid.ItemsSource = filteredData;
            UpdatePriorityVisualization(filteredData);
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}