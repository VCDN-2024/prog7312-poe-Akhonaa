﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WeGotYou
{
    public partial class LocalEventsWindow : Window
    {
        public List<Event> eventsList;
        private Queue<Event> upcomingEventsQueue;
        private Dictionary<string, int> searchHistory = new Dictionary<string, int>();

        public LocalEventsWindow()
        {
            InitializeComponent();
            LoadEvents();
        }

        //method that generates all events
        private void LoadEvents()
        {
            eventsList = new List<Event>
            {
                new Event { Title = "Beach Clean-Up", Date = DateTime.Now.AddDays(2), Category = "Environment" },
                new Event { Title = "Tree Planting Day", Date = DateTime.Now.AddDays(10), Category = "Environment" },
                new Event { Title = "Local Farmers Market", Date = DateTime.Now.AddDays(5), Category = "Commerce" },
                new Event { Title = "Business Networking Event", Date = DateTime.Now.AddDays(12), Category = "Commerce" },
                new Event { Title = "Youth Sports Day", Date = DateTime.Now.AddDays(3), Category = "Sports" },
                new Event { Title = "Community Soccer Match", Date = DateTime.Now.AddDays(8), Category = "Sports" },
                new Event { Title = "Music Festival", Date = DateTime.Now.AddDays(7), Category = "Entertainment" },
                new Event { Title = "Outdoor Movie Night", Date = DateTime.Now.AddDays(15), Category = "Entertainment" },
                new Event { Title = "Career Fair", Date = DateTime.Now.AddDays(1), Category = "Employment" },
                new Event { Title = "Job Skills Workshop", Date = DateTime.Now.AddDays(9), Category = "Employment" }
            };

            upcomingEventsQueue = new Queue<Event>(eventsList.OrderBy(e => e.Date));
            DisplayUpcomingEvents();
        }

        private void DisplayUpcomingEvents()
        {
            EventsListBox.Items.Clear();

            foreach (var ev in upcomingEventsQueue)
            {
                EventsListBox.Items.Add($"{ev.Title} - {ev.Date.ToShortDateString()} ({ev.Category})");
            }

            if (upcomingEventsQueue.Any())
            {
                var nextEvent = upcomingEventsQueue.Peek();
                NextEventTextBlock.Text = $"Next Event: {nextEvent.Title} on {nextEvent.Date.ToShortDateString()}";
            }
            else
            {
                NextEventTextBlock.Text = "No upcoming events.";
            }
        }

        public void SortEventsByDate(bool latest)
        {
            if (latest)
            {
                upcomingEventsQueue = new Queue<Event>(eventsList.OrderByDescending(e => e.Date));
            }
            else
            {
                upcomingEventsQueue = new Queue<Event>(eventsList.OrderBy(e => e.Date));
            }

            DisplayUpcomingEvents();
        }

        public void FilterEventsByCategory(List<string> categories)
        {
            var filteredEvents = eventsList.Where(e => categories.Contains(e.Category)).ToList();
            upcomingEventsQueue = new Queue<Event>(filteredEvents);
            DisplayUpcomingEvents();
        }

        public List<string> GetAllCategories()
        {
            return eventsList.Select(e => e.Category).Distinct().ToList();
        }

        private void ProcessNextEvent_Click(object sender, RoutedEventArgs e)
        {
            if (upcomingEventsQueue.Any())
            {
                var processedEvent = upcomingEventsQueue.Dequeue();
                MessageBox.Show($"Processed event: {processedEvent.Title}");
                DisplayUpcomingEvents();
            }
            else
            {
                MessageBox.Show("No events to process.");
            }
        }

        private void SearchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string searchText = SearchTextBox.Text.ToLower();
            var filteredEvents = eventsList.Where(ev => ev.Title.ToLower().Contains(searchText)).ToList();

            EventsListBox.Items.Clear();
            foreach (var ev in filteredEvents)
            {
                EventsListBox.Items.Add($"{ev.Title} - {ev.Date.ToShortDateString()} ({ev.Category})");
            }

            if (string.IsNullOrWhiteSpace(SearchTextBox.Text))
            {
                SearchPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {       //algorithm that captures the first 3 letters of the searched phrase to then determine the search history
                SearchPlaceholder.Visibility = Visibility.Hidden;

                if (searchText.Length >= 3)
                {
                    if (searchHistory.ContainsKey(searchText))
                    {
                        searchHistory[searchText]++;
                    }
                    else
                    {
                        searchHistory.Add(searchText, 1);
                    }
                }
            }
        }

        private void OpenFilterWindow_Click(object sender, RoutedEventArgs e)
        {
            FilterWindow filterWindow = new FilterWindow(this);
            filterWindow.ShowDialog();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Hide(); // hides LocalEventsWindow instead of closing it
            MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
            if (mainWindow != null)
            {
                mainWindow.Show(); // Re-shows the MainWindow
            }
        }

        public Dictionary<string, int> GetSearchHistory()
        {
            return searchHistory;
        }
    }

    public class Event
    {
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string Category { get; set; }
    }
}