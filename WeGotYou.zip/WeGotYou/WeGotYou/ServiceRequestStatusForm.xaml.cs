﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WeGotYou
{
    /// <summary>
    /// Interaction logic for ServiceRequestStatusForm.xaml
    /// </summary>
    public partial class ServiceRequestStatusForm : Window
    {
        private List<ServiceRequest> serviceRequests;

        // Constructor now accepts the serviceRequests list
        public ServiceRequestStatusForm(List<ServiceRequest> requests)
        {
            InitializeComponent();
            serviceRequests = requests;

            // Populate the DataGrid with the actual service requests
            RequestDataGrid.ItemsSource = serviceRequests;
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string requestId = RequestIdTextBox.Text.Trim();
            var request = serviceRequests.FirstOrDefault(r => r.RequestId.Equals(requestId, StringComparison.OrdinalIgnoreCase));

            if (request != null)
            {
                StatusDetailsTextBlock.Text = $"Request ID: {request.RequestId}\n" +
                                             $"Status: {request.Status}\n" +
                                             $"Date Submitted: {request.ReportedAt.ToString("MM/dd/yyyy")}\n" +
                                             $"Description: {request.Description}\n" +
                                             $"Location: {request.Location}\n" +
                                             $"Priority: {request.Priority}";
            }
            else
            {
                StatusDetailsTextBlock.Text = "Service request not found.";
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RequestDataGrid.ItemsSource = null;
            RequestDataGrid.ItemsSource = serviceRequests;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void RequestDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

    public class ServiceRequest
    {
        public string RequestId { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime ReportedAt { get; set; }
        public string Priority { get; set; }
        public string Location { get; set; }
        public string Category { get; set; }
    }

}
